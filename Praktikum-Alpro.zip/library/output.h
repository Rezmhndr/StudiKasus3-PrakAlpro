#include <iostream>
using namespace std;

class Output {
  public :
    void cetak(){
      cout<< "Anda sebagai output \n";
      cout << "STRUK PEMBELIAN KELOMPOK 7\n ";
      cout << "Yang dibeli : \n";
      cout << "  Ayam Geprek  -> " << data_file[3] << endl;
      cout << "  Ayam Goreng  -> " << data_file[] << endl;
      cout << "  Udang Goreng  -> " << data_file[] << endl;
      cout << "  Cumi Goreng  -> " << data_file[] << endl;
      cout << "  Ayam Bakar   -> " << data_file[4] << endl;
      cout << "Harga Total  Rp. " << data_file[0] << endl;
      cout << "Diskon       Rp. " << data_file[1] << endl;
      cout << "Harga Bayar  Rp. " << data_file[2] << endl;
    }

    void getData(){
      ambil_data.open("../dummy/out_proses.txt");
      string t;
      while(!ambil_data.eof()){
        ambil_data >> t;
        cout<< "data file : "<< t << endl;
          }
      ambil_data.close();
    }
  private :
    ifstream ambil_data;
    string data_file[30];
    int index = 0;
};