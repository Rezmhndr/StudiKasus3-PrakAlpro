using namespace std;

class input {
  public :
    void cetak(){
      cout << "Aplikasi penjualan ayam\n";
      cout << "Menu yang tersedia : ";
      cout << "1) Ayam Goreng Rp. 17.000\n";
      cout << "2) Ayam Bakar Rp. 25.000\n\n";
      cout << "3) Udang Goreng Rp. 19.000\n\n";
      cout << "4) Cumi Goreng Rp. 20.000";
      cout << "5) Ayam Geprek Rp. 21.000";
      cout << "Pesan ayam goreng -> "; cin >> bnyk_aymGr;
      cout << "Pesan ayam bakar - > "; cin >> bnyk_aymBk;
      cout << "Pesan Udang Goreng - > "; cin >> bnyk_udang;
      cout << "Pesan Cumi Goreng - > "; cin >> bnyk_cumi;
      cout << "Pesan ayam Geprek - > "; cin >> bnyk_aymgrk;
    }
  private:
  int bnyk_aymGr, bnyk_aymBk, bnyk_aymgrk, bnyk_cumi, bnyk_udang;
};