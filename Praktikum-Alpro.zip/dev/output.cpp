#include "../library/output.h"
#include <fstream>
#include <iostream>

int main() {
  Output output;
  output.getData();
  return 0;
}