#include <iostream>
#include "../library/input.h"

int main(){
  input input;
  input.cetak();
  cout << "Testi testi isnt it work";
  return 0;
}